<?php

namespace Drupal\Tests\Core\Plugin\Fixtures;

use Drupal\Core\Plugin\Context\ContextDefinition;

/**
 * Inherited class used for testing.
 *
 * @see \Drupal\Tests\Core\Plugin\Context\ContextDefinitionIsSatisfiedTest
 */
class InheritedContextDefinition extends ContextDefinition {}
